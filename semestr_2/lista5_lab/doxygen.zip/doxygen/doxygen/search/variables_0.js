var searchData=
[
  ['appheight_52',['AppHeight',['../classcom_1_1example_1_1autocadv2_1_1_main.html#ac2b4f9c17f9e6e05e32690a7ab81bc7a',1,'com::example::autocadv2::Main']]],
  ['appwidth_53',['AppWidth',['../classcom_1_1example_1_1autocadv2_1_1_main.html#a7bb8a9f74327d693a59f84baf49710b3',1,'com::example::autocadv2::Main']]]
];
