var searchData=
[
  ['constructmenu_54',['constructMenu',['../classcom_1_1example_1_1zad6labv2_1_1_get_parameters_menu.html#a642009c4bea6501bf7835f22695b7b66',1,'com::example::zad6labv2::GetParametersMenu']]]
];
