var searchData=
[
  ['off_32',['off',['../classcom_1_1example_1_1zad6labv2_1_1_cell.html#a7ea3ab2df3cb90ebe9c8f4b6abc595e3',1,'com::example::zad6labv2::Cell']]]
];
