var searchData=
[
  ['isactive_69',['isActive',['../classcom_1_1example_1_1zad6labv2_1_1_cell.html#a0269d1a30833a53abd818e034f6305e5',1,'com::example::zad6labv2::Cell']]]
];
