var searchData=
[
  ['setactive_75',['setActive',['../classcom_1_1example_1_1zad6labv2_1_1_cell.html#af8c85e4bfae8f83847c84efeea7caf61',1,'com::example::zad6labv2::Cell']]],
  ['setanchorpanelayout_76',['SetAnchorPaneLayout',['../classcom_1_1example_1_1zad6labv2_1_1_color_board.html#a65357052cd5229b970f99c8bc0a0cd64',1,'com::example::zad6labv2::ColorBoard']]],
  ['setcolor_77',['setColor',['../classcom_1_1example_1_1zad6labv2_1_1_cell.html#adfb301670a72ff6307e57ab37a585fd4',1,'com::example::zad6labv2::Cell']]],
  ['start_78',['start',['../classcom_1_1example_1_1zad6labv2_1_1_main_application.html#a21bb5a55182da0906826f135f8014edf',1,'com::example::zad6labv2::MainApplication']]]
];
