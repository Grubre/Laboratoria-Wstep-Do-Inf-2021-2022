var searchData=
[
  ['get_8',['get',['../classcom_1_1example_1_1zad6labv2_1_1_color_board.html#a276615d7f882e2f046cc2b946d586ae0',1,'com::example::zad6labv2::ColorBoard']]],
  ['getchangespeed_9',['getChangeSpeed',['../classcom_1_1example_1_1zad6labv2_1_1_color_board.html#a4052205dc7d33cbaef5bdd922453e724',1,'com.example.zad6labv2.ColorBoard.getChangeSpeed()'],['../classcom_1_1example_1_1zad6labv2_1_1_get_parameters_menu.html#a185ff97c241dc7bae5560bbac63248ec',1,'com.example.zad6labv2.GetParametersMenu.getChangeSpeed()']]],
  ['getcolor_10',['getColor',['../classcom_1_1example_1_1zad6labv2_1_1_cell.html#a909ce011304585340b7b306f5c8e5956',1,'com::example::zad6labv2::Cell']]],
  ['getgridheight_11',['getGridHeight',['../classcom_1_1example_1_1zad6labv2_1_1_color_board.html#aa28bc7e182ad27233e52bd75912ac40c',1,'com::example::zad6labv2::ColorBoard']]],
  ['getgridwidth_12',['getGridWidth',['../classcom_1_1example_1_1zad6labv2_1_1_color_board.html#a21d741b0108e4caaf702ad618d91a319',1,'com::example::zad6labv2::ColorBoard']]],
  ['getgridx_13',['getGridX',['../classcom_1_1example_1_1zad6labv2_1_1_cell.html#aa334b5f1d6e9eae0b78ba0da15126967',1,'com::example::zad6labv2::Cell']]],
  ['getgridy_14',['getGridY',['../classcom_1_1example_1_1zad6labv2_1_1_cell.html#ac658355b57b8e09a5f1b97870fa9197f',1,'com::example::zad6labv2::Cell']]],
  ['getheight_15',['getHeight',['../classcom_1_1example_1_1zad6labv2_1_1_get_parameters_menu.html#a53e5100484240448629f3136574e68c2',1,'com::example::zad6labv2::GetParametersMenu']]],
  ['getneighbourcolors_16',['getNeighbourColors',['../classcom_1_1example_1_1zad6labv2_1_1_color_board.html#ade06487300d44c042a70f098ddeeacd7',1,'com::example::zad6labv2::ColorBoard']]],
  ['getparametersmenu_17',['GetParametersMenu',['../classcom_1_1example_1_1zad6labv2_1_1_get_parameters_menu.html',1,'com.example.zad6labv2.GetParametersMenu'],['../classcom_1_1example_1_1zad6labv2_1_1_get_parameters_menu.html#acdacf50ccc0df62335f471e6f1a8b0d9',1,'com.example.zad6labv2.GetParametersMenu.GetParametersMenu()']]],
  ['getparametersmenu_2ejava_18',['GetParametersMenu.java',['../_get_parameters_menu_8java.html',1,'']]],
  ['getprobability_19',['getProbability',['../classcom_1_1example_1_1zad6labv2_1_1_color_board.html#a09a4c31f00b9d528efda347c0b471dc6',1,'com.example.zad6labv2.ColorBoard.getProbability()'],['../classcom_1_1example_1_1zad6labv2_1_1_get_parameters_menu.html#af68a76c79e70e0f396108c48ba11af28',1,'com.example.zad6labv2.GetParametersMenu.getProbability()']]],
  ['getrandomcolor_20',['getRandomColor',['../classcom_1_1example_1_1zad6labv2_1_1_color_board.html#a4a36e822ab4aea0a40b4ccc7ee69254e',1,'com::example::zad6labv2::ColorBoard']]],
  ['getstage_21',['getStage',['../classcom_1_1example_1_1zad6labv2_1_1_main_application.html#a0671b2b366ae3edbcc1c29973b2dd6f1',1,'com::example::zad6labv2::MainApplication']]],
  ['getwidth_22',['getWidth',['../classcom_1_1example_1_1zad6labv2_1_1_get_parameters_menu.html#ab93aaf4f880e48b50cecc2ebde77d4ee',1,'com::example::zad6labv2::GetParametersMenu']]]
];
