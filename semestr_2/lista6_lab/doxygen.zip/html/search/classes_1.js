var searchData=
[
  ['getparametersmenu_42',['GetParametersMenu',['../classcom_1_1example_1_1zad6labv2_1_1_get_parameters_menu.html',1,'com::example::zad6labv2']]]
];
