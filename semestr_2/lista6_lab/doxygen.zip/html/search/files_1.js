var searchData=
[
  ['getparametersmenu_2ejava_49',['GetParametersMenu.java',['../_get_parameters_menu_8java.html',1,'']]]
];
