var searchData=
[
  ['boardscene_0',['boardScene',['../classcom_1_1example_1_1zad6labv2_1_1_main_scene.html#af253e243e3bd305f30f3b6443f9fc9cf',1,'com::example::zad6labv2::MainScene']]]
];
